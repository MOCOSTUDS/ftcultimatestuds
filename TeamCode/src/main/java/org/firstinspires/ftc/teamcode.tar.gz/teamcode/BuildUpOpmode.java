package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import org.firstinspires.ftc.teamcode.OdometryGlobalCoordinatePosition;


/**
 * Created by Sarthak on 10/4/2019.
 */
@TeleOp(name = "BuildUp OpMode")
public class BuildUpOpmode extends LinearOpMode {

    StudBot studbot = new StudBot();


    @Override
    public void runOpMode() throws InterruptedException {

        studbot.init(hardwareMap);
        waitForStart();
        ShooterBeltSpeedVelocity shooterUpdate = new ShooterBeltSpeedVelocity(studbot.getShooter(), 100);
        Thread shooterThread = new Thread(shooterUpdate);
        shooterThread.start();


        /**
         * *****************
         * OpMode Begins Here
         * *****************
         */
        //Create and start GlobalCoordinatePosition thread to constantly update the global coordinate positions\
        OdometryGlobalCoordinatePosition globalPositionUpdate =
                    new OdometryGlobalCoordinatePosition(studbot.verticalLeft,
                            studbot.verticalRight, studbot.horizontalRight, studbot.getDrive().COUNTS_PER_INCH, 75);
        Thread positionThread = new Thread(globalPositionUpdate);
        globalPositionUpdate.reverseRightEncoder();
        globalPositionUpdate.reverseNormalEncoder();
        positionThread.start();


        //shooterUpdate.maintainSpeedModeStart(0.9);
        while (opModeIsActive()) {
            if (gamepad2.right_trigger > 0.2) {
                studbot.getShooter().setClawShoot();
            } else {
                studbot.getShooter().setClawOpen();
            }
            if (gamepad2.left_bumper){
                studbot.getIntake().setBack();
            }else{
                studbot.getIntake().setFeed();
            }
            studbot.getElevator().moveElevator(-(gamepad2.right_stick_y*gamepad2.right_stick_y*gamepad2.right_stick_y));
            // handle elevator
            if (studbot.getElevator().readyToShoot())
            {
                shooterUpdate.maintainSpeedModeStart(2.0);
            } else {
                shooterUpdate.setBackMode();
            }

            if (gamepad1.y){
                studbot.getDrive().setTarget(0.0,40.0, 0.0);
                studbot.getDrive().move(globalPositionUpdate.returnXCoordinateInInches(),
                        globalPositionUpdate.returnYCoordinateInInches() ,
                        globalPositionUpdate.returnOrientation());



            } else  if (gamepad1.x){
                studbot.getDrive().setTarget(40.0,0.0, 90.0);
                studbot.getDrive().move(globalPositionUpdate.returnXCoordinateInInches(),
                        globalPositionUpdate.returnYCoordinateInInches() ,
                        globalPositionUpdate.returnOrientation());



            }else  if (gamepad1.a){
                studbot.getDrive().setTarget(0.0,0.0, 0.0);
                studbot.getDrive().move(globalPositionUpdate.returnXCoordinateInInches(),
                        globalPositionUpdate.returnYCoordinateInInches() ,
                        globalPositionUpdate.returnOrientation());


            } else  if (gamepad2.dpad_down){
                studbot.getDrive().setTarget(0.0,0.0, 0.0);
                studbot.getDrive().move(globalPositionUpdate.returnXCoordinateInInches(),
                        globalPositionUpdate.returnYCoordinateInInches() ,
                        globalPositionUpdate.returnOrientation());
            } else  if (gamepad2.dpad_left){
                studbot.getDrive().setTarget(0.0,0.0, -90.0);
                studbot.getDrive().move(globalPositionUpdate.returnXCoordinateInInches(),
                        globalPositionUpdate.returnYCoordinateInInches() ,
                        globalPositionUpdate.returnOrientation());
            } else  if (gamepad2.dpad_right){
                studbot.getDrive().setTarget(0.0,0.0, 90.0);
                studbot.getDrive().move(globalPositionUpdate.returnXCoordinateInInches(),
                        globalPositionUpdate.returnYCoordinateInInches() ,
                        globalPositionUpdate.returnOrientation());
            } else  if (gamepad2.dpad_up){
                studbot.getDrive().setTarget(0.0,0.0, 180.0);
                studbot.getDrive().move(globalPositionUpdate.returnXCoordinateInInches(),
                        globalPositionUpdate.returnYCoordinateInInches() ,
                        globalPositionUpdate.returnOrientation());
            } else  if (gamepad1.b){
                studbot.getDrive().setTarget(0.0,0.0, -90.0);
                studbot.getDrive().move(globalPositionUpdate.returnXCoordinateInInches(),
                        globalPositionUpdate.returnYCoordinateInInches() ,
                        globalPositionUpdate.returnOrientation());



            } else {


                // do drive
                double vertical = -1.0 * gamepad1.left_stick_y;
                double horizontal = -gamepad1.left_stick_x;
                double pivot = gamepad1.right_stick_x;
                studbot.getDrive().teleDrive(vertical, horizontal, pivot);
            }

            telemetry.addData("Velocity", shooterUpdate.returnVelocity());
            //telemetry.addData("Power", shooterUpdate.returnPower());
            //telemetry.addData("Thread Active", shooterThread.isAlive());
            //telemetry.addData("switch0", studbot.getElevator().digIn0.getState());
            //telemetry.addData("switch1=", studbot.digIn1.getState());
            //telemetry.addData("detaltT=", shooterUpdate.getLastTime());
            telemetry.addData("elevator=", studbot.getElevator().getElevatorPosition() - studbot.getElevator().elevator_zero_position);

            telemetry.addData("X Position", globalPositionUpdate.returnXCoordinateInInches());
            telemetry.addData("Y Position", globalPositionUpdate.returnYCoordinateInInches());
            telemetry.addData("Orientation (Degrees)", globalPositionUpdate.returnOrientation());
            telemetry.addData("Thread Active", positionThread.isAlive());

            //telemetry.addData("vertical left", studbot.verticalLeft.getCurrentPosition());
            //telemetry.addData("vertical right", studbot.verticalRight.getCurrentPosition());
            //telemetry.addData("horizontal", studbot.horizontalRight.getCurrentPosition());



            //telemetry.update();



            telemetry.update();

        }
        //Stop the thread
        shooterUpdate.stop();
        studbot.getIntake().stopAll();

    }


}
